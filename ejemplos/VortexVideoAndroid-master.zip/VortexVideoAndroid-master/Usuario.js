var Usuario = function(nombre){
    this.nombre = nombre;
};